#pragma once

void PrintLoaderError(const char * fmt, ...);

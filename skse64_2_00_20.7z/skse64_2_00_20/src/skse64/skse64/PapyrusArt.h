#pragma once

#include "GameTypes.h"

class VMClassRegistry;

namespace papyrusArt
{
	void RegisterFuncs(VMClassRegistry* registry);
};

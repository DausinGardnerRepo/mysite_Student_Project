#include "skse64/PapyrusInterfaces.h"

// 82677E39AC1FFB7F2E1C28FBABC2FC971DB49882+F7
RelocPtr <IObjectHandlePolicy*> g_objectHandlePolicy(0x031D07A8);

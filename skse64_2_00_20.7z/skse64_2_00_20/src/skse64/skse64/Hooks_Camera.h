#pragma once

void Hooks_Camera_Commit(void);
